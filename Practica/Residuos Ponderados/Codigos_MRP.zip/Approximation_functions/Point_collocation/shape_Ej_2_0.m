function N=shape_Ej_2_0(x,m)
%
%   N = x^m*(1-x);
%

N = x.^(m).*(1-x);
