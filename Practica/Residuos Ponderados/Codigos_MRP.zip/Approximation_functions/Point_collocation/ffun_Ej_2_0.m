function phi = ffun_Ej_2_0(x)
%
% rutina para escribir la funcion que se desee aproximar
%

phi = x.^4.*(1-x);  
phi = 1*(sin(-1.8*pi*x)+x);