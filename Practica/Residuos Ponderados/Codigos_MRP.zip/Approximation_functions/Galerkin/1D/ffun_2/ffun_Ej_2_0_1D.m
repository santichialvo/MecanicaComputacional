function z = ffun_Ej_2_0_1D(x)
%
%
%

z = x.*sin(2*pi*x);
