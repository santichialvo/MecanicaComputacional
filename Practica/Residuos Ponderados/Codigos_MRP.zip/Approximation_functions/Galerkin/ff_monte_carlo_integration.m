function f = ff_monte_carlo_integration(x,y)
%
%  
%

f = 4-x.^2-y.^2;
