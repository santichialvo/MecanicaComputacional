function N=shape_function(x,y,ll,mm)
%
%
%

N  = sin(ll*pi*x).*sin(mm*pi*y);
