function z = ffun_Ej_2_0_1D(x,y)
%
%
%

z = x.*(x-1).*y.*(y-1);
