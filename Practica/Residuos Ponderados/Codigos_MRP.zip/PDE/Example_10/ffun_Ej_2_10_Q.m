function [Q]= ffun_Ej_2_10_Q(x)
%
%
%

Q = 10*x;