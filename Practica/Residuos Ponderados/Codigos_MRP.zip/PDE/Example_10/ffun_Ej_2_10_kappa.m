function [kappa]= ffun_Ej_2_10_kappa(phi)
%
%
%

kappa = 1 + 0.1*phi;