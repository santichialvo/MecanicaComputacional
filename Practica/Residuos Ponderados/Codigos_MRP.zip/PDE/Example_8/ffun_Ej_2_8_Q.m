function [Q]= ffun_Ej_2_8_Q(x)
%
%
%

Q=(x<=0.5);